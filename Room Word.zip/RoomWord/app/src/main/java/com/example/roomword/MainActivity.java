package com.example.roomword;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rvWord = findViewById(R.id.rvWord);

        final WordListAdapter adapter = new WordListAdapter(new WordListAdapter.WordDiff());

        rvWord.setAdapter(adapter);
        rvWord.setLayoutManager(new LinearLayoutManager(this));
    }
}